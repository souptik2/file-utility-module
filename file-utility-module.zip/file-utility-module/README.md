# File-utility-module Extension

Add description ...


...


...


Add this dependency to your application pom.xml

```
<groupId>icoe.custom.connector</groupId>
<artifactId>file-utility-module</artifactId>
<version>1.0.0</version>
<classifier>mule-plugin</classifier>
```
