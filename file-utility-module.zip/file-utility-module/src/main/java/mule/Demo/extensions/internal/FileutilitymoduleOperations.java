package mule.Demo.extensions.internal;

import static org.mule.runtime.extension.api.annotation.param.MediaType.ANY;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.mule.runtime.extension.api.annotation.param.MediaType;
import org.mule.runtime.extension.api.annotation.param.Optional;
import org.mule.runtime.extension.api.annotation.param.display.Summary;
import org.mule.runtime.extension.api.annotation.Alias;
import org.mule.runtime.extension.api.annotation.param.Config;
import org.mule.runtime.extension.api.annotation.param.Connection;


/**
 * This class is a container for operations, every public method in this class will be taken as an extension operation.
 */
public class FileutilitymoduleOperations {
	
	
	public class FileAttributes {
        private FileTime lastModifiedTime;
        private FileTime lastAccessTime;
        private FileTime creationTime;
        private long fileSize;
        private String path;
        private String fileName;

        // Getters and Setters
        public FileTime getLastModifiedTime() {
            return lastModifiedTime;
        }

        public void setLastModifiedTime(FileTime lastModifiedTime) {
            this.lastModifiedTime = lastModifiedTime;
        }

        public FileTime getLastAccessTime() {
            return lastAccessTime;
        }

        public void setLastAccessTime(FileTime lastAccessTime) {
            this.lastAccessTime = lastAccessTime;
        }

        public FileTime getCreationTime() {
            return creationTime;
        }

        public void setCreationTime(FileTime creationTime) {
            this.creationTime = creationTime;
        }

        public long getFileSize() {
            return fileSize;
        }

        public void setFileSize(long fileSize) {
            this.fileSize = fileSize;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getFileName() {
            return fileName;
        }

        public void setFileName(String fileName) {
            this.fileName = fileName;
        }
    }
	

  /**
   * Provides the path of the files in the given directory.
   */
  @MediaType(value = ANY, strict = false)
  @Summary("Provides the path of the files in the given directory.")
  public List<String> GetFilePaths(@Alias("directoryPath")String directoryPath,@Optional @Alias("regex") String regex) throws IOException {
		List<String>response=new ArrayList<>();
		String dirpath=directoryPath.trim().replace("\\", "/");
		
		try {
			System.out.println("==== fetching file paths from path: "+directoryPath + " with regex: "+regex) ;
			Stream<Path> stream = Files.list(Paths.get(directoryPath));
			 response= stream.filter(file -> !Files.isDirectory(file))
					//.map(Path::toAbsolutePath)
					.map(Path::toString)
					.map(file -> file.toString().trim())
					.map(file -> file.substring(dirpath.length()+1))
					.filter(file -> matchesRegex(file,regex))
					
					
					//.filter(file -> (endswith == null || endswith.isEmpty() || file.endsWith(endswith)) && (file.contains("mule-buffer") || file.contains("dw-buffer")))
					.map(file-> file.join("/", dirpath, file))
					.map(file-> file.toString().replace("\\", "/"))
					.collect(Collectors.toList());
			
			 System.out.println("==== fetched total " + response.size() +" file paths");
			
		}
		catch(Exception e) {
			System.out.println("==== could not fetch file paths with regex: "+regex +" from path: "+directoryPath);
			e.printStackTrace();
		}
		return response;
	}
  
  /**
   * Provides the attributes of the given file.
   */
  @MediaType(value = ANY, strict = false)
  @Summary("Provides the attributes of the given file.")
  public FileAttributes GetFileAttributes (@Alias("FilePath")String filepath){
	  FileAttributes fileAttributes = new FileAttributes();
      String formattedPath = filepath.trim().replace("\\", "/");
      Path filePath = Paths.get(formattedPath);
      int lastIndexOfSlash = formattedPath.lastIndexOf('/');

      try {
          BasicFileAttributes attr = Files.readAttributes(filePath, BasicFileAttributes.class);
          fileAttributes.setLastModifiedTime(attr.lastModifiedTime());
          fileAttributes.setLastAccessTime(attr.lastAccessTime());
          fileAttributes.setCreationTime(attr.creationTime());
          fileAttributes.setFileSize(attr.size());
          fileAttributes.setPath(formattedPath);
          fileAttributes.setFileName(formattedPath.substring(lastIndexOfSlash + 1));
      } catch (IOException e) {
          System.err.println("Error reading attributes: " + e.getMessage());
      }

      return fileAttributes;
  }
  
  
  
  
  
  private static boolean matchesRegex(String fileName, String regex) {
	  boolean found=true;
	  
	  if(regex != null && !regex.isEmpty()) {
      Pattern pattern=Pattern.compile(regex);  
	  Matcher matcher = pattern.matcher(fileName);
      found = matcher.find();
      //System.out.println("filename: " + fileName + " regex: " + found);
      }
      return found;
     
  }

  
  
  
}
